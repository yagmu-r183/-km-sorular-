public abstract class School {
    abstract void doStudy();
}
