public class HighSchool extends School{
    @Override
    void doStudy() {
        System.out.println("study in high school");
    }

    void doClubActivity(){
        System.out.println("do Club Activity in high school");
    }
}
