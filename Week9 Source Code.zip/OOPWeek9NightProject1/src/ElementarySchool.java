public class ElementarySchool extends School{
    @Override
    void doStudy() {
        System.out.println("do study in Elementary School");
    }

    void playGames() {
        System.out.println(" play games in Elementary School");
    }
}
