public class Cat extends Animal{
    @Override
    void eat() {
        System.out.println("cat eats");
    }

    void meuw(){
        System.out.println("meuw");
    }
}