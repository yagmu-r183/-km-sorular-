public class Plane extends Vehicle{
    void drive(){
        System.out.println("drive plane");
    }

    void fly(){
        System.out.println("fly");
    }
}
