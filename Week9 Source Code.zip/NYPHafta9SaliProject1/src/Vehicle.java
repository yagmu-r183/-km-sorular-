public abstract class Vehicle {
    abstract void drive();

    void test(){
        System.out.println("test");
    }
}
