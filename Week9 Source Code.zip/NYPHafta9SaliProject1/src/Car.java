public class Car extends Vehicle{
    void drive(){
        System.out.println("drive the car");
    }
}
