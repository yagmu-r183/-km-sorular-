public class Ship extends Vehicle{


    @Override
    void drive() {
        System.out.println("drive the ship");
    }

    void swim(){
        System.out.println("ship swims");
    }

}
