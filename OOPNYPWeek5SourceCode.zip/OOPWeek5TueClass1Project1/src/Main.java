public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

      Player player1 = new Player(1,"back","player 1");
      Player player2 = new Player(2,"forward","player 2");
      Player player3 = new Player(3,"middle are","player 3");

        System.out.println(Player.getCounter());

    }

}