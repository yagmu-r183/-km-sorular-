public class BritishShortHair extends Cat{

    String someProb;

    BritishShortHair(String color, int age){
        super(color, age);
    }

}
