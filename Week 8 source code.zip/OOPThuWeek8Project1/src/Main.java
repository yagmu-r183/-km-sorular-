public class Main {
    public static void main(String[] args) {
        Cat cat = new Cat("red",5);
        Dog dog = new Dog("blue", "kangal");
       // cat.eat();
       // dog.eat();

        dog.test();

      //  Animal[] animals = {cat, dog};
    }
}