public class ParentClass {

    public void method1(){
        System.out.println("method 1 in parent");
    }
}
