public class Main {
    public static void main(String[] args) {
        GrandChildClass grandchild = new GrandChildClass();
        grandchild.test();

        ChildClass child = new ChildClass();
        child.test();
    }
}