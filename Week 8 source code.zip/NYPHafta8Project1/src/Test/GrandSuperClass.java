package Test;

public class GrandSuperClass {
    public void method1(){
        System.out.println("method1 in GrandSuperClass");
    }
}
