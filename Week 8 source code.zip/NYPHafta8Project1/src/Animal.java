public class Animal {
    protected String color;

    Animal(String color){
        this.color = color;
    }

    public void eat(){
        System.out.println("animal is eating");

    }
}
