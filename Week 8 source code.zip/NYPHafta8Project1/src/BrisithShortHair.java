public class BrisithShortHair extends Cat{

    BrisithShortHair(String color, int age)
    {
        super(color,age);
    }
}
