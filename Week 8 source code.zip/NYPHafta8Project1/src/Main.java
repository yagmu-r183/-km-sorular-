import Test.Subclass;
import Test.SuperClass;

public class Main {
    public static void main(String[] args){


        Cat cat = new Cat("red", 5);
        
//        Subclass subclass = new Subclass();
//        subclass.test();
//
//        SuperClass superClass = new SuperClass();
//        superClass.test();
    }
}
