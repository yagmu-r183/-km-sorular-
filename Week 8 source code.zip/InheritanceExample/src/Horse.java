public class Horse extends Animal{
    @Override
    void eat(){
        System.out.println("horse is eating");
    }
}
