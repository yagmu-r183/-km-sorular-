public class Cat extends Animal{

   @Override
   void eat(){
        System.out.println("cat is eating");
   }

    void meuw(){
        System.out.println("meuw");
    }
}
