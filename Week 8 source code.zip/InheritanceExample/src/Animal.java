public abstract class Animal {
    abstract void eat();

    void test(){
        System.out.println("test");
    }
}
