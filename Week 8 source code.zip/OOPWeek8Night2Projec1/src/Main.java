public class Main {
    public static void main(String[] args) {
        Cat cat = new Cat("red", 4);
        Dog dog = new Dog("blue", "bulldog");
        cat.test();

        //cat.eat();
       // dog.eat();

       // cat.
    }
}