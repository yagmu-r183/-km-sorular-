public class Animal  {
    String color;

    Animal(String color){
        this.color = color;
    }

    Animal(){}
    public void eat(){
        System.out.println("animal is eating");
    }
}
