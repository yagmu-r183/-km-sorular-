public class BritishShortHair extends Cat{
    public String someAtt;
    BritishShortHair(String color, int age){
        super(color,age);
    }

}
