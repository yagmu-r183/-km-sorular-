public class ShortBritishHair extends Cat{

    ShortBritishHair(String color, int age){
        super(color,age);
    }
    void test(){

    }
}
