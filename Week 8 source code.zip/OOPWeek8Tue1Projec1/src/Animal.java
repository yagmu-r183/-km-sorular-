public class Animal {
    protected String color;


    public Animal(String color){
        this.color = color;
    }

    public Animal(){

    }
    public void eat(){
        System.out.println("animal is eating");
    }
}
