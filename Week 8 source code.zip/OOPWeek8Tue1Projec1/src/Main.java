public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        Cat cat = new Cat("red", 5);
        cat.eat();

        cat.color ="red";

        Dog dog = new Dog("white", "kangal");
        dog.eat();

        ShortBritishHair sbh = new ShortBritishHair("gray",4);




    }
}