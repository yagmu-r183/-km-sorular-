

interface ColorPrintBehaviours{
    void colorPrint();
}

interface FaxBehaviours{
    void fax();
}


interface ScanBehaviours{
    void scan();
}

