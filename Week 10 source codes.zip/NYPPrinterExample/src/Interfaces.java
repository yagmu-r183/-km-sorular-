
interface ColoredPrintBehaviour{
    void colorPrint();
}


interface FaxBehaviour{
    void fax();
}

interface ScanBehaviour{
    void scan();
}