public abstract class Printer {
    abstract void print();
}
