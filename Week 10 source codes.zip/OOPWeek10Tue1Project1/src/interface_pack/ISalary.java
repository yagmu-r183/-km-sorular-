package interface_pack;

public interface ISalary {
    double computeSalary();
}
