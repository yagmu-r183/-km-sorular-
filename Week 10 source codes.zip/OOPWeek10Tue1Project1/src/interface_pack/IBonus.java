package interface_pack;

public interface IBonus {

    double addBonus();
}
