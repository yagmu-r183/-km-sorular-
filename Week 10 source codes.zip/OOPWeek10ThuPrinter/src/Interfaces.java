
interface ColorPrintBehaviour{
    void colorPrint();
}

interface FaxBehaviour{
    void fax();
}

interface ScanBehaviour{
    void scan();
}