package other;

public class Worker {
    public String name;
    int ssn;
    private double wage;

}
