package diger;

public class Worker {
    int ssn;
    public String name;
}
