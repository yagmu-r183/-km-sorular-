public class Employee {
    int ssn;
    public String name;

    Employee(){
        this.ssn = 0;
        this.name ="no name";
    }

    Employee(int ssn, String name){
        this.ssn =ssn;
        this.name = name;
    }




}
