package other;

public class Computer {
    int modelYear;
    public String serial;

    private int ramSize;

}
