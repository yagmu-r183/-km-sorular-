package otherpackage;

public class Worker {
    public String name;
    int id;
}
